# mypackage
This program was created as a practise on how to publish my own python package.